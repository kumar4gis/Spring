package junit.test;

import java.net.URISyntaxException;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.sun.org.apache.xerces.internal.util.URI;

import net.codejava.Person;

@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class SpringBootDemoApplicationTests {

	 @LocalServerPort
	    int randomServerPort;
	     
	    @Test
	    public void testAddEmployeeSuccess() throws URISyntaxException 
	    {
	        RestTemplate restTemplate = new RestTemplate();
	        final String baseUrl = "http://localhost:"+randomServerPort+"/person/";
	        URI uri = new URI(baseUrl);
	        Person person = new Person(1L, "KK", "Kumar");
	         
	        HttpHeaders headers = new HttpHeaders();
	        headers.set("X-COM-PERSIST", "true");      
	 
	        HttpEntity<Person> request = new HttpEntity<>(person, headers);
	         
	        ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
	         
	        //Verify request succeed
	        Assertions.assertEquals(201, result.getStatusCodeValue());
	    }
	     
	    @Test
	    public void testAddEmployeeMissingHeader() throws URISyntaxException 
	    {
	        RestTemplate restTemplate = new RestTemplate();
	        final String baseUrl = "http://localhost:"+randomServerPort+"/Person/";
	        URI uri = new URI(baseUrl);
	        Person person = new Person(2L, "Adam", "Gilly");
	         
	        HttpHeaders headers = new HttpHeaders();
	 
	        HttpEntity<Person> request = new HttpEntity<>(person, headers);
	         
	        try
	        {
	            restTemplate.postForEntity(uri, request, String.class);
	            Assertions.fail();
	        }
	        catch(HttpClientErrorException ex) 
	        {
	            //Verify bad request and missing header
	            Assertions.assertEquals(400, ex.getRawStatusCode());
	            Assertions.assertEquals(true, ex.getResponseBodyAsString().contains("Missing request header"));
	        }
	    }
	 
	    @Test
	    public void testGetEmployeeListSuccessWithHeaders() throws URISyntaxException 
	    {
	        RestTemplate restTemplate = new RestTemplate();
	         
	        final String baseUrl = "http://localhost:"+randomServerPort+"/employees/";
	        URI uri = new URI(baseUrl);
	         
	        HttpHeaders headers = new HttpHeaders();
	        headers.set("X-COM-LOCATION", "USA");
	 
	        HttpEntity<Person> requestEntity = new HttpEntity<>(null, headers);
	 
	        try
	        {
	            restTemplate.exchange(uri, HttpMethod.GET, requestEntity, String.class);
	            Assertions.fail();
	        }
	        catch(HttpClientErrorException ex) 
	        {
	            //Verify bad request and missing header
	            Assertions.assertEquals(400, ex.getRawStatusCode());
	            Assertions.assertEquals(true, ex.getResponseBodyAsString().contains("Missing request header"));
	        }
	    }
	}
